﻿using System.Runtime.CompilerServices;
using System.CodeDom.Compiler;
using System.Configuration;

namespace TestApp.Properties {
    
    
    [CompilerGeneratedAttribute()]
    [GeneratedCodeAttribute("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.6.0.0")]
    internal sealed partial class Settings : ApplicationSettingsBase {
        
        private static Settings defaultInstance = ((Settings)(ApplicationSettingsBase.Synchronized(new Settings())));
        
        public static Settings Default {
            get {
                return defaultInstance;
            }
        }
    }
}
